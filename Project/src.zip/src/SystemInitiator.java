import UserInterfaceSubsystem.ScreenView;

/**
 * @(#)SystemInitiator.java
 *
 * Bombplan application
 *
 * @author Saner Turhaner
 * @version 1.00 2016/4/16
 */
 
public class SystemInitiator 
{    
    public static void main(String[] args) 
    {
    	ScreenView screen = ScreenView.getInstance();
    }
}

