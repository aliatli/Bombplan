package ModelSubsystem;

public class BombTimerCanceller extends Bonus {

	public BombTimerCanceller( int x, int y) {
		super();
		this.x = x;
		this.y = y;
		this.type = 3;
		getIconFromFile("src/Sources/Images/bombTimerCanceller.png");
	}

}