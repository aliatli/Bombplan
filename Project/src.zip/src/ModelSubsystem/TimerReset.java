package ModelSubsystem;

public class TimerReset extends Bonus {

	public TimerReset( int x, int y) {
		super();
		this.x = x;
		this.y = y;
		this.type = 5;
		getIconFromFile("src/Sources/Images/timerReset.png");
	}

}