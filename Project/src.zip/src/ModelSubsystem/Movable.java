package ModelSubsystem;

public interface Movable {

	void move(int movement);

}