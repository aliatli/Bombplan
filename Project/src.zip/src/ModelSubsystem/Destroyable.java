package ModelSubsystem;

public interface Destroyable {

	void destroy();

}