package ModelSubsystem;

public class Wall extends MapObject {

	/*
	type 1: destroyable wall
	type 2: non-destroyable wall
	*/
	protected int type;
}