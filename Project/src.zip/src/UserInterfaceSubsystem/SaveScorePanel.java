package UserInterfaceSubsystem;

import javax.swing.*;

/**
 * Created by sahinfurkan on 29/04/16.
 */
public class SaveScorePanel extends JPanel {
}
